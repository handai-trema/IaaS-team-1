A collection of step definitions for use with Trema and Trema apps.
These steps are highly specific to Trema.
