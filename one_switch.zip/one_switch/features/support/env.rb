require 'aruba/cucumber'
require 'rest_api'

def app
  RestApi
end
