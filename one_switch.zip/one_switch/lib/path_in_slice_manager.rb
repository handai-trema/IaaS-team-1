require 'path_manager'
require 'slice'
require 'slice_exceptions'
require 'slice_extensions'
require 'arp_table'
require 'interface'
require 'routing_table'

# L2 routing switch with virtual slicing.
class PathInSliceManager < PathManager
  def start
    super
    logger.info "#{name} started."
  end

  # rubocop:disable MethodLength
  def packet_in(_dpid, packet_in)
    slice = Slice.find do |each|
      each.member?(packet_in.slice_source) &&
      each.member?(packet_in.slice_destination(@graph))
    end
    ports = if slice
              path = maybe_create_shortest_path_in_slice(slice.name, packet_in)
              path ? [path.out_port] : []
            else
              external_ports(packet_in)
            end
    packet_out(packet_in.raw_data, ports)
  end
  # rubocop:enable MethodLength

  private

  def packet_out(raw_data, ports)
    ports.each do |each|
      send_packet_out(each.dpid,
                      raw_data: raw_data,
                      actions: SendOutPort.new(each.port_no))
    end
  end

  def maybe_create_shortest_path_in_slice(slice_name, packet_in)
    path = maybe_create_shortest_path(packet_in)
    return unless path
    path.slice = slice_name
    path
  end

  def external_ports(packet_in)
    Slice.all.each_with_object([]) do |each, ports|
      next unless each.member?(packet_in.slice_source)
      ports.concat external_ports_in_slice(each, packet_in.source_mac)
    end
  end

  def external_ports_in_slice(slice, packet_in_mac)
    slice.each_with_object([]) do |(port, macs), result|
      next unless @graph.external_ports.any? { |each| port == each }
      result << port unless macs.include?(packet_in_mac)
    end
  end
  
  def external_ports_ip(packet_in)
    Slice.all.each_with_object([]) do |each, ports|
      next unless each.member?(packet_in.slice_source)
      ports.concat external_ports_in_slice_ip(each, packet_in.source_ip_address)
    end
  end

  def external_ports_in_slice_ip(slice, packet_in_ip)
    slice.each_with_object([]) do |(port, ips), result|
      next unless @graph.external_ports.any? { |each| port == each }
      result << port unless ips.include?(packet_in_ip)
    end
  end
  
  
  
  
  
  
  
  
  
  
  
  def packet_in_ipv4(dpid, packet_in)
    if forward?(packet_in)
      forward(dpid, packet_in)
    elsif packet_in.ip_protocol == 1
      icmp = Icmp.read(packet_in.raw_data)
      packet_in_icmpv4_echo_request(dpid, packet_in) if icmp.icmp_type == 8
    else
      logger.debug "Dropping unsupported IPv4 packet: #{packet_in.data}"
    end
  end

  # rubocop:disable MethodLength
  def packet_in_icmpv4_echo_request(dpid, packet_in)
    icmp_request = Icmp.read(packet_in.raw_data)
    if @arp_table.lookup(packet_in.source_ip_address)
      send_packet_out(dpid,
                      raw_data: create_icmp_reply(icmp_request).to_binary,
                      actions: SendOutPort.new(packet_in.in_port))
    else
      send_later(dpid,
                 interface: Interface.find_by(port_number: packet_in.in_port),
                 destination_ip: packet_in.source_ip_address,
                 data: create_icmp_reply(icmp_request))
    end
  end
  # rubocop:enable MethodLength

	def sent_to_router?(packet_in)
    return true if packet_in.destination_mac.broadcast?
    interface = Interface.find_by(port_number: packet_in.in_port)
    interface && interface.mac_address == packet_in.destination_mac
  end

  def forward?(packet_in)
    !Interface.find_by(ip_address: packet_in.destination_ip_address)
  end

  # rubocop:disable MethodLength
  # rubocop:disable AbcSize
  def forward(dpid, packet_in)
    next_hop = resolve_next_hop(packet_in.destination_ip_address)

    interface = Interface.find_by_prefix(next_hop)
    return if !interface || (interface.port_number == packet_in.in_port)

    arp_entry = @arp_table.lookup(next_hop)
    if arp_entry
      actions = [SetSourceMacAddress.new(interface.mac_address),
                 SetDestinationMacAddress.new(arp_entry.mac_address),
                 SendOutPort.new(interface.port_number)]
      send_flow_mod_add(dpid,
                        match: ExactMatch.new(packet_in), actions: actions)
      send_packet_out(dpid, raw_data: packet_in.raw_data, actions: actions)
    else
      send_later(dpid,
                 interface: interface,
                 destination_ip: next_hop,
                 data: packet_in.data)
    end
  end
  # rubocop:enable AbcSize
  # rubocop:enable MethodLength

  def resolve_next_hop(destination_ip_address)
    interface = Interface.find_by_prefix(destination_ip_address)
    if interface
      destination_ip_address
    else
      @routing_table.lookup(destination_ip_address)
    end
  end

  def create_icmp_reply(icmp_request)
    Icmp::Reply.new(identifier: icmp_request.icmp_identifier,
                    source_mac: icmp_request.destination_mac,
                    destination_mac: icmp_request.source_mac,
                    destination_ip_address: icmp_request.source_ip_address,
                    source_ip_address: icmp_request.destination_ip_address,
                    sequence_number: icmp_request.icmp_sequence_number,
                    echo_data: icmp_request.echo_data)
  end

  def send_later(dpid, options)
    destination_ip = options.fetch(:destination_ip)
    @unresolved_packet_queue[destination_ip] += [options.fetch(:data)]
    send_arp_request(dpid, destination_ip, options.fetch(:interface))
  end

  def flush_unsent_packets(dpid, arp_reply, interface)
    destination_ip = arp_reply.sender_protocol_address
    @unresolved_packet_queue[destination_ip].each do |each|
      rewrite_mac =
        [SetDestinationMacAddress.new(arp_reply.sender_hardware_address),
         SetSourceMacAddress.new(interface.mac_address),
         SendOutPort.new(interface.port_number)]
      send_packet_out(dpid, raw_data: each.to_binary_s, actions: rewrite_mac)
    end
    @unresolved_packet_queue[destination_ip] = []
  end

  def send_arp_request(dpid, destination_ip, interface)
    arp_request =
      Arp::Request.new(source_mac: interface.mac_address,
                       sender_protocol_address: interface.ip_address,
                       target_protocol_address: destination_ip)
    send_packet_out(dpid,
                    raw_data: arp_request.to_binary,
                    actions: SendOutPort.new(interface.port_number))
  end
end
