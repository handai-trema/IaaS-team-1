./bin/slice add slice1
./bin/slice add slice2
./bin/slice add_host --ip 192.168.1.101 --port 0x1:1 --slice slice1
./bin/slice add_host --ip 192.168.1.102 --port 0x1:2 --slice slice2
./bin/slice add_host --ip 192.168.1.103 --port 0x1:3 --slice slice1
./bin/slice add_host --ip 192.168.1.104 --port 0x1:4 --slice slice2
./bin/slice add_host --ip 192.168.1.105 --port 0x1:5 --slice slice1
./bin/slice add_host --ip 192.168.1.106 --port 0x1:6 --slice slice2
