Rake Tasks
==========

A collection of rake tasks for use with [Trema][trema] and Trema apps.

[trema]: https://github.com/trema/trema
