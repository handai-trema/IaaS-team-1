# Change log

## develop (unreleased)


## 0.4.1 (12/2/2015)
### Bugs fixed
* Fix LoadError


## 0.4.0 (12/2/2015)
### Changes
* Trema 0.8.4.


## 0.3.0 (3/29/2015)
### Misc
* The initial release version of routing_switch that runs on [pure-Ruby Trema](https://github.com/trema/trema_ruby).
